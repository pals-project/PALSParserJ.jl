Quick links
===========

* `API documentation (Doxygen) <./doxygen/index.html>`_

* `YAML playground <https://play.yaml.io/main/parser?input=IyBFZGl0IE1lIQoKJVlBTUwgMS4yCi0tLQpmb286IEhlbGxvLCBZQU1MIQpiYXI6IFsxMjMsIHRydWVdCmJhejoKLSBvbmUKLSB0d28KLSBudWxsCg==>`_

* YAML Test Suite `online <https://matrix.yaml.info>`_ / `Github <https://github.com/yaml/yaml-test-suite>`_

* `rapidyaml Github repo <https://github.com/biojppm/rapidyaml>`_

  * `Issues <https://github.com/biojppm/rapidyaml/issues>`_

  * `Pull Requests <https://github.com/biojppm/rapidyaml/pull>`_

  * `Kanban board <https://github.com/users/biojppm/projects/1/views/1>`_

* Latest release: `0.11.1 <https://github.com/biojppm/rapidyaml/releases/tag/v0.11.1>`_

  * `Release page [0.11.1] <https://github.com/biojppm/rapidyaml/releases/tag/v0.11.1>`_

  * `README [0.11.1] <https://github.com/biojppm/rapidyaml/blob/v0.11.1/README.md>`_

* Since latest release (master branch):

  * `README [master] <https://github.com/biojppm/rapidyaml/blob/master/README.md>`_

  * `Changelog [master] <https://github.com/biojppm/rapidyaml/blob/master/changelog/current.md>`_
